challenging star DBOSS darshan
